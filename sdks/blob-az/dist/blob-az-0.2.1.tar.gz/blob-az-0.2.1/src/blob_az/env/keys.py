import os

CONN_STR = os.environ.get("BLOB_CONN_STR")