import os
CONN_STR = os.getenv('PUBSUB_CONN_STR')